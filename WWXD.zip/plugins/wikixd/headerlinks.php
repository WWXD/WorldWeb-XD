<?php

$headerlinks[actionLink('wiki')] = 'Wiki';
	
?>