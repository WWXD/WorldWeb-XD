<?php

$permCats['wiki'] = __('Wiki');

$permDescs['wiki'] = array(
	'wiki.editpages' => __('Edit pages'),
	'wiki.makepagesspecial' => __('Make pages special'),
	'wiki.deletepages' => __('Delete pages'),
);

?>