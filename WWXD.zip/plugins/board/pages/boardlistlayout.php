<table class="center margin outline">
<tr class="header1"><th>Board Listing</th></tr>
<tr class="cell1"><td><a href="../board/">BlargBoard</a></td></tr>
<?php if ($mobileLayout) { ?><tr class="cell2"><td><a href="../board1/">ABXD</a></td></tr>
<tr class="cell1"><td><a href="../board2/">RHCafe's</a></td></tr><?php } else { ?>
<tr class="cell2"><td><a href="../board2/">RHCafe's</a></td></tr><?php } ?></table>